from django.conf.urls.defaults import *
from django.views.generic.simple import redirect_to
from mysite.polls.models import Poll

from django.contrib import admin
admin.autodiscover()

info_dict = {
    'queryset': Poll.objects.all(),
}

urlpatterns = patterns('',
     (r'^polls/', include('mysite.polls.urls')),
    # Uncomment this for admin:
     url(r'^admin/', include(admin.site.urls)),
     (r'^$', redirect_to, {'url': '/polls'}),
)
