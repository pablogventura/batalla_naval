import random
import unittest

from django.test import TestCase
from django.test.client import Client

from polls.models import Poll, Choice

import random

class PollTestBase(TestCase):
    """Base class for Poll testing"""

    def setUp(self):
        """Set up for Poll testing; it creates a sample poll"""
        self.poll = Poll.objects.create(question="Is this a test?", pub_date="2008-10-08")
        Choice.objects.create(poll=self.poll, choice="Yes", votes=0)
        Choice.objects.create(poll=self.poll, choice="No", votes=0)


class PollModelTestCase(PollTestBase):
    """Tests for the Poll model"""

    def test_initial(self):
        """Test for the initial state of a poll"""
        # Check there are the choices
        self.failUnless(len(self.poll.choice_set.all()) == 2)
        # Check there are no votes
        self.assertEqual(self.poll.total_votes(), 0)

    def test_totalVotes(self):
        """Test the total_votes method"""
        yes = random.randint(1, 10)
        no = random.randint(1, 10)
        yes_choice = self.poll.choice_set.get(choice='Yes')
        yes_choice.votes = yes
        yes_choice.save()
        no_choice = self.poll.choice_set.get(choice='No')
        no_choice.votes = no
        no_choice.save()
        self.assertEqual(self.poll.total_votes(), yes + no)


class PollViewTestCase(PollTestBase):
    """Test the voting form view"""

    fixtures = ['polls.json']

    def setUp(self):
        """Overriding setUp to include a TestClient"""
        super(PollViewTestCase, self).setUp()
        #self.client = Client()
        self.vote_url = '/polls/%s/vote/' % str(self.poll.id)

    def test_voteForYes(self):
        """Test voting for yes"""
        choice_obj = self.poll.choice_set.get(choice="Yes")
        response = self.client.post(self.vote_url, {'choice': choice_obj.id})
        self.assertEqual(self.poll.total_votes(), 1)
        self.assertEqual(self.poll.choice_set.get(choice='Yes').votes, 1)

    def test_voteCancel(self):
        """Test cancel voting"""
        response = self.client.post(self.vote_url, {'cancel': 'Cancel'})
        self.assertEqual(self.poll.total_votes(), 0)

    def test_voteFailed(self):
        """Test if no choice is passed"""
        before = self.poll.total_votes()
        response = self.client.post(self.vote_url, {})
        self.assert_("You did not select a choice" in response.content)
        self.failUnless(before == self.poll.total_votes())

    def test_voteVarious(self):
        """Test managing several votes"""
        yes = random.randint(1, 10)
        no = random.randint(1, 10)
        for i in range(0, yes):
            choice_obj = self.poll.choice_set.get(choice="Yes")
            self.client.post(self.vote_url, {'choice': choice_obj.id})
        for i in range(0, no):
            choice_obj = self.poll.choice_set.get(choice="No")
            self.client.post(self.vote_url, {'choice': choice_obj.id})

        self.assertEqual(self.poll.choice_set.get(choice='Yes').votes, yes)
        self.assertEqual(self.poll.choice_set.get(choice='No').votes, no)
        self.assertEqual(self.poll.total_votes(), yes + no)

    # patching example
    def patch(self, obj, member, new_value):
        """Replace 'member' in 'obj' with 'new_value'. Restore at tear down."""
        old = getattr(obj, member, None)
        setattr(obj, member, new_value)
        self.addCleanup(lambda: setattr(obj, member, old))

    def test_patch_sample(self):
        def my_random_int(range_min, range_max):
            return 3
        self.patch(random, 'randint', my_random_int)
        self.assertEqual(random.randint(0, 9), 3)

def suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(PollModelTestCase))
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(PollViewTestCase))
    return suite
