
from models import Poll, Choice
from django.contrib import admin

class ChoiceInline(admin.StackedInline):
    model = Choice
    extra = 3

class PollAdmin(admin.ModelAdmin):
    list_display = ('question', 'pub_date')
    inlines = (ChoiceInline, )
admin.site.register(Poll, PollAdmin)
