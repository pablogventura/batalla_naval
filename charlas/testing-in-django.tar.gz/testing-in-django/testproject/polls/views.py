# Create your views here.

from django.http import Http404, HttpResponseRedirect
from django.template.response import TemplateResponse
from django.shortcuts import get_object_or_404

from polls.models import Choice, Poll


def vote(request, poll_id):
    if request.POST.get('cancel', None):
        return HttpResponseRedirect('/polls/')

    p = get_object_or_404(Poll, pk=poll_id)
    try:
        selected_choice = p.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the poll voting form.
        context = {'object': p, 'error_message': "You did not select a choice."}
        return TemplateResponse(request, template='polls/poll_detail.html',
                                context=context)
    else:
        selected_choice.votes += 1
        selected_choice.save()
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect('/polls/%s/results/' % p.id)
