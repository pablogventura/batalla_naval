from datetime import datetime

from django.db import models


class Poll(models.Model):
    """
    Create a poll
    >>> poll = Poll.objects.create(question="Is this a test?", pub_date="2008-10-08")
    >>> c1 = Choice.objects.create(poll=poll, choice="Yes", votes=0)
    >>> c2 = Choice.objects.create(poll=poll, choice="No", votes=0)

    # There are no votes
    >>> poll.total_votes()
    0

    # Adding some votes
    >>> c1.votes = 3; c1.save()
    >>> c2.votes = 2; c2.save()

    # Count the votes now
    >>> poll.total_votes()
    5
    """

    question = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published', default=datetime.now)

    def total_votes(self):
        ret = sum([i.votes for i in self.choice_set.iterator()])
        return ret

    def __unicode__(self):
        return self.question


class Choice(models.Model):
    poll = models.ForeignKey(Poll)
    choice = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __unicode__(self):
        return self.choice
