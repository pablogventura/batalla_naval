from django.conf.urls.defaults import *

from demo.libros.views import *

urlpatterns = patterns('',
     (r'^listar/$', mostrar_todos),
     (r'^(?P<id>\d+)/ver/$', mostrar_libro),

)
