from django.shortcuts import render_to_response
from demo.libros.models import *
	

def mostrar_libro (request, id):
	libro = Libro.objects.get(pk=id)
	return render_to_response("ficha_libro.html", {'item': libro})


def mostrar_todos (request):
	list = Libro.objects.all()
	return render_to_response("tabla_libros.html", {'list': list})
