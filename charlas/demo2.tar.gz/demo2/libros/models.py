from django.db import models
from django.contrib import admin

class Autor(models.Model):
	nombre = models.CharField(max_length=100)
	def __unicode__(self):
		return self.nombre
	
class Libro(models.Model):
	titulo = models.CharField(max_length=100)
	autor = models.ForeignKey(Autor)
	fecha = models.DateField()
	def __unicode__(self):
		return self.titulo
	class Meta:
	    ordering = ['fecha']
	
class LibroAdmin(admin.ModelAdmin):
    fields = ['titulo','autor','fecha']
    list_display = ('titulo','autor','fecha')
    date_hierarchy = 'fecha'
    search_fields = ['titulo', 'autor']
    list_filter = ['autor']
    

admin.site.register(Autor)
admin.site.register(Libro, LibroAdmin)

